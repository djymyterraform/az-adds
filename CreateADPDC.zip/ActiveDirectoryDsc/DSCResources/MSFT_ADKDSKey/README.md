# Description

The ADKDSKey DSC resource will manage KDS Root Keys within Active Directory. The KDS root keys are used to begin generating Group Managed Service Account (gMSA) passwords.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
